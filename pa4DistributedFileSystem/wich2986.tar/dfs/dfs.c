#include <stdio.h>
#include <stdlib.h>
#include <string.h>      /* for fgets */
#include <strings.h>     /* for bzero, bcopy */
#include <unistd.h>      /* for read, write */
#include <sys/types.h>
#include <sys/socket.h>  /* for socket use */
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>
#include <dirent.h>
#include <openssl/md5.h>
#include <poll.h>

#define MAXBUF   8192  /* max buffer size */
#define MAXLINE  1024  /* max I/O buffer size */

void *thread(void* vargp);

struct threadArgs {
    int* connid;
    char* serverDir;
    int* authorizedUsers;
};

///// GENERAL
unsigned int md5Hash(MD5_CTX* md5, char* word) {
    char hold[MAXLINE];
    strcpy(hold, word);

    MD5_Update(&md5,hold,strlen(hold));
    MD5_Final(&hold, &md5);

    unsigned int ret = (unsigned int)hold;
    printf("%u\n", hold);
    return ret;
}

int hashDest(char* hashInput){
    char hashResult[MAXLINE];
    int dest = (((short)MD5(hashInput, strlen(hashInput), &hashResult))%1013);
    return abs(dest);
}

int open_listenfd(int port) 
{
    int listenfd, optval=1;
    struct sockaddr_in serveraddr;
  
    /* Create a socket descriptor */
    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        return -1;

    /* Eliminates "Address already in use" error from bind. */
    if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, 
                   (const void *)&optval , sizeof(int)) < 0)
        return -1;

    /* listenfd will be an endpoint for all requests to port
       on any IP address for this host */
    bzero((char *) &serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET; 
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY); 
    serveraddr.sin_port = htons((unsigned short)port); 
    if (bind(listenfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) < 0)
        return -1;

    /* Make it a listening socket ready to accept connection requests */
    if (listen(listenfd, MAXLINE) < 0)
        return -1;
    return listenfd;
} 

void loadAuthorized(int users[1013])
{
	FILE* fp = fopen("dfs.config", "r");
    char * readLine = NULL;
    int read;
    int len;

    while((read = getline(&readLine, &len, fp)) != -1){
    	users[hashDest(readLine)] = 1;
    }

    return 0;
}

int nextWord(char* buffer, char* dest, int start, int limit)
{
    char charDump = buffer[start];
    char strDump[limit];
    int i = 0;
    int strI = 0;
    while((charDump == ' ' || charDump == '\r' || charDump == '\n') && start + i <= limit - 1)
    {
    	i++;
    	charDump = buffer[i + start];
    }

    while(!(charDump == ' ' || charDump == '\r' || charDump == '\n'||start + i >= limit - 1 ))
    {
        strDump[strI] = charDump;
        strI++;
        i++;
        charDump = buffer[i + start];
    }
    strDump[strI] = '\0';
    strcpy(dest, strDump);

    return i+1;
}

//// File handling
int getFileData(char* filename, int* breaks, int* size)
{
    FILE* fp;
    fp = fopen(filename, "r"); 
    if(fp == NULL){
        return -1;
    }
    fseek(fp, 0L, SEEK_END);
    *size = ftell(fp); 
    fseek(fp, 0L, SEEK_SET);
    *breaks = (int)(*size/4);
    fclose(fp);
    return 0;
}


int bufferToFile(char* filename, char* buffer, int fileSize, char* mode)
{
	FILE* fp;

    fp = fopen(filename, mode);
    if(fp == NULL)
        return 1;

    fwrite(buffer, 1, fileSize, fp);
    fclose(fp);
    return 0;
}

int getFileParts(char* dir, char* filename, char* buffer)
{
	FILE* fp;
	char tempPath[MAXLINE];
	strcpy(buffer, "");
	for(int i = 0; i < 4; i++)
	{
		sprintf(tempPath, "%s/%s.%d", dir, filename, i);
		fp = fopen(tempPath, "r");
		if(fp != NULL)
		{
			sprintf(buffer, "%s%s\n", buffer, tempPath);
			fclose(fp);
		}
	}
}

//// Handle requests
int handelPut(int connid, char* filename, int size, char* buf, int bufPos)
{
	char buffer[MAXBUF];
	int len = 0;
	int totalLen = (MAXLINE - bufPos);

	if(size <= (MAXLINE - bufPos))
	{
		memcpy(&buffer, buf, size);
		bufferToFile(filename, &buffer, size, "w+");
	}

	else
	{
        // not sure if works yet...
        len = MAXBUF - bufPos;
        bufferToFile(filename, buf, len, "w+");
		while(totalLen < size)
		{
			if(MAXBUF <= (size - totalLen))
			{
				len = MAXBUF;
			}
			else 
			{
				len = size - totalLen;
			}

			read(connid, &buffer, len);
			bufferToFile(filename, &buffer, len, "a");
			totalLen += len;
		}
	}

	fprintf(stderr, "%d bytes of %s were saved\n", size, filename);
	return 0;
}

int handelGet(int connid, char* filename)
{
	int size, dump;
	getFileData(filename, &dump, &size);
	FILE* fp;
    fp = fopen(filename,"r");

	int readLen = 0;
    int curLen = 0;
    char buf[MAXBUF];
    sprintf(buf,"file %s %d\n", &filename[5], size);
    send(connid, &buf, strlen(buf), MSG_NOSIGNAL);
    while(readLen < size)
    {
        if(MAXBUF <= (size - readLen))
        {
            curLen = MAXBUF;
        }
        else 
        {
            curLen = size - readLen;
        } 
        fread(&buf, 1, curLen, fp);
        readLen += curLen;
        send(connid, &buf, curLen, MSG_NOSIGNAL);
    }
}

void* thread(void* vargp)
{   
    struct threadArgs* args = (struct threadArgs*) vargp;
    int connid = *args->connid;
    int* authorizedUsers = args->authorizedUsers;
    char serverDir[MAXLINE];
    strcpy(serverDir, args->serverDir);
    pthread_detach(pthread_self()); 
    free(vargp);

    char buf[MAXBUF];
    char extract1[MAXLINE];
    char extract2[MAXLINE];

    int len;

    /// authorization
    len = recv(connid, &buf, MAXLINE, 0);
    if(authorizedUsers[hashDest(buf)] == 0){
    	strcpy(&buf, "Unauthorized User");
    	fprintf(stderr, "Unauthorized User\n");
    	len = send(connid, &buf, strlen(buf), MSG_NOSIGNAL);
	    close(connid);
    }
    else
    {
    	strcpy(&buf, "Authorized User");
    	fprintf(stderr, "Authorized User\n");
    	len = send(connid, &buf, strlen(buf), MSG_NOSIGNAL);
    }

    /// process request
    while(1)
    {
	    len = read(connid, &buf, MAXLINE);

		int linePtr = 0;
		linePtr = nextWord(&buf, &extract1, linePtr, strlen(buf));
		if(strcmp(extract1, "get") == 0)
	    {
	    	// get filename
	    	linePtr += nextWord(&buf, &extract1, linePtr, strlen(buf));
	    	getFileParts(serverDir,extract1, &extract2);
			char extract3[MAXLINE];

	    	len = 0;
	    	int limit = strlen(extract2)-1;
	    	while(len < limit)
		    {
		        len += nextWord(&extract2, &extract3, len, MAXLINE);
		        handelGet(connid, &extract3);
		    }

		    strcpy(buf, "end");
		    len = send(connid, &buf, strlen(buf), MSG_NOSIGNAL);
		    fprintf(stderr, "Sent %s data\n", extract1);
	    }

	    else if (strcmp(extract1, "put") == 0)
	    {
	    	// get filename
	    	linePtr += nextWord(&buf, &extract1, linePtr, strlen(buf));
	    	// get size
	    	linePtr += nextWord(&buf, &extract2, linePtr, strlen(buf));

	    	char filepath[MAXLINE];
	    	sprintf(filepath, "%s/%s", serverDir, extract1);
	    	handelPut(connid, filepath, atoi(extract2), &buf[linePtr], linePtr);

	    	sprintf(&buf, "Successfully saved %s \n", filepath);
	    	len = send(connid, &buf, strlen(buf), MSG_NOSIGNAL);

	    	fprintf(stderr, "%s\n", buf);
	    }

	    else if (strcmp(extract1, "list") == 0)
	    {
	    	strcpy(&buf, "Unable to interpret request");
	    	len = send(connid, &buf, strlen(buf), MSG_NOSIGNAL);
	    }

	    else
	    {
	    	strcpy(&buf, "Finnished or unable to interpret request");
	    	fprintf(stderr, "Closing connection\n");
	    	len = send(connid, &buf, strlen(buf), MSG_NOSIGNAL);
		    close(connid);
		    break;
	    }
   }
   return NULL;
}


int main(int argc, char **argv) 
{
    int listenfd, *connfdp, port, clientlen = sizeof(struct sockaddr_in);
    struct sockaddr_in clientaddr;
    struct threadArgs* args;
    pthread_t tid; 

    if (argc < 2) {
	    fprintf(stderr, "usage: %s <directory> <port>\n", argv[0]);
	    exit(0);
    }

    /* Initialize authorized users */
    int authorizedUsers[1013];
	loadAuthorized(authorizedUsers);
    
    port = atoi(argv[2]);
    listenfd = open_listenfd(port);
    while (1) {
        args = malloc(sizeof(struct threadArgs));
        
        args->connid = malloc(sizeof(int));
        *args->connid = accept(listenfd, (struct sockaddr*)&clientaddr, &clientlen);
        
        args->serverDir = malloc(sizeof(char)*MAXLINE);
        strcpy(args->serverDir, argv[1]);
        args->authorizedUsers = malloc(sizeof(int*));
        args->authorizedUsers = &authorizedUsers;
        
        pthread_create(&tid, NULL, thread, args);
    }
}