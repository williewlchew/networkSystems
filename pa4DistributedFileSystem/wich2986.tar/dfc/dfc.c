// Sandbox for testing parts of the project

#include <stdio.h>
#include <stdlib.h>
#include <string.h>      /* for fgets */
#include <strings.h>     /* for bzero, bcopy */
#include <unistd.h>      /* for read, write */
#include <sys/types.h>
#include <sys/socket.h>  /* for socket use */
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>
#include <dirent.h>
#include <openssl/md5.h>
#include <poll.h>

#define MAXBUF   8192  /* max buffer size */
#define MAXLINE  1024  /* max I/O buffer size */

///// GENERAL
unsigned int md5Hash(MD5_CTX* md5, char* word) {
    char hold[MAXLINE];
    strcpy(hold, word);

    MD5_Update(&md5,hold,strlen(hold));
    MD5_Final(&hold, &md5);

    unsigned int ret = (unsigned int)hold;
    printf("%u\n", hold);
    return ret;
}

int hashDest(char* hashInput){
    char hashResult[MAXLINE];
    int dest = (((short)MD5(hashInput, strlen(hashInput), &hashResult))%13)%4;
    return abs(dest);
}

int nextWord(char* buffer, char* dest, int start, int limit)
{
    char charDump = buffer[start];
    char strDump[limit];
    int i = 0;

    while(!(charDump == ' '||charDump == ':'  || charDump == '\r' || charDump == '\n'||start + i >= limit - 1 ))
    {
        strDump[i] = charDump;
        i++;
        charDump = buffer[i + start];
    }
    strDump[i] = '\0';
    i++;
    strcpy(dest, strDump);

    return i;
}

int open_connectfd(char* hostname, int portno, char* creds) 
{
    int sockfd, serverlen, n, status;
    struct hostent *server;
    struct sockaddr_in serveraddr;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        fprintf(stderr, "ERROR opening socket\n");
        return -1;
    }
    server = gethostbyname(hostname);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host as %s\n", hostname);
        return -2;
    }

    /* build the server's Internet address*/
    bzero((char *) &serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serveraddr.sin_addr.s_addr, server->h_length);
    serveraddr.sin_port = htons(portno);
    serverlen = sizeof(serveraddr);
    status = connect(sockfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
    
    if (status == -1) {
        perror("connect");
        return -1;
    }

    send(sockfd, creds, strlen(creds), MSG_NOSIGNAL);
    char buf[MAXLINE];
    recv(sockfd, &buf, MAXLINE, 0);
    fprintf(stderr, "%s\n", buf);



    return sockfd;
}

int processConfig(char addrs[4][MAXLINE], int connections[4], char* username, char* password)
{
    FILE* fp = fopen("dfc.config", "r");
    char * readLine = NULL;
    char buf[MAXLINE];
    char addr[MAXLINE];
    char port[MAXLINE];
    size_t len = 0;

    for(int i = 0; i < 4; i++)
    {
        len = getline(&readLine, &len, fp);
        strcpy(buf, readLine);
        len = nextWord(&buf, &addr, 0, strlen(buf));
        len = nextWord(&buf, &port, len, strlen(buf));
        
        strcpy(addrs[i], addr);
        connections[i] = atoi(port);
    }

    len = getline(&readLine, &len, fp);
    nextWord(readLine, username, 0, MAXLINE);
    len = getline(&readLine, &len, fp);
    strcpy(password, readLine);

    return 0;
}


//// File Handing
int getFileData(char* filename, int* breaks, int* size)
{
    FILE* fp;
    fp = fopen(filename, "r"); 
    if(fp == NULL){
        return -1;
    }
    fseek(fp, 0L, SEEK_END);
    *size = ftell(fp); 
    fseek(fp, 0L, SEEK_SET);
    *breaks = (int)(*size/4);
    fclose(fp);
    return 0;
}

int bufferToFile(char* filename, char* buffer, int fileSize, char* mode)
{
    FILE* fp;

    fp = fopen(filename, mode);
    if(fp == NULL)
        return 1;

    fwrite(buffer, 1, fileSize, fp);
    fclose(fp);
    return 0;
}

int reconstuctFile(char* filename)
{
    int size, dump;
    char tempPath[MAXLINE];
    char buf[MAXBUF];
    FILE* fp = fopen(filename, "w+");
    fclose(fp);

    fp = fopen(filename, "a");
    for(int i = 0; i < 4; i++)
    {
        sprintf(tempPath, "temp/%s.%d", filename, i);
        getFileData(tempPath, &dump, &size);
        FILE* tfp = fopen(tempPath, "r");
        if(tfp == NULL)
        {
            continue;
        }

        if(size <= MAXBUF)
        {
            fread(&buf, 1, size, tfp);
            fwrite(&buf, 1, size, fp);
        }

        else
        {
            int wroteLen = 0;
            int curLen = 0;

            while(wroteLen < size)
            {
                if(MAXBUF <= (size - wroteLen))
                {
                    curLen = MAXBUF;
                }
                else 
                {
                    curLen = size - wroteLen;
                } 
                fread(&buf, 1, curLen, tfp);
                wroteLen += curLen;
                fwrite(&buf, 1, curLen, fp);
            }
        }
        fclose(tfp);


    }
    fclose(fp);
}

//// Upload
int uploadFilePart(char* filename, int connid, int breaks, int part, int extras)
{
    char buf[MAXBUF];
    int len;
    FILE* fp;
    fp = fopen(filename, "r"); 
    fseek(fp, part*breaks, SEEK_SET);
    breaks = breaks + extras;

    sprintf(&buf, "put %s.%d %d\n", filename, part, breaks);
    len = send(connid, &buf, strlen(buf), MSG_NOSIGNAL);
    if(len < 0)
    {
        fprintf(stderr,"error sending data to server %d \n", connid);
        return;
    }

    int readLen = 0;
    int curLen = 0;
    
    while(readLen < breaks)
    {
        if(MAXBUF <= (breaks - readLen))
        {
            curLen = MAXBUF;
        }
        else 
        {
            curLen = breaks - readLen;
        } 
        fread(&buf, 1, curLen, fp);
        readLen += curLen;
        send(connid, &buf, readLen, MSG_NOSIGNAL);
    }

    strcpy(&buf, "");
    len = recv(connid, &buf, MAXLINE, 0);
    if(len < 0)
    {
        fprintf(stderr,"error receiving response from server %d \n", connid);
        return;
    }
    else
    {
        fprintf(stderr,"Server %d: %s \n", connid, buf);
        return;
    }
}

int uploadFile(char* filename, char addrs[4][MAXLINE], int ports[4], int sendMap[4][4][2], char* creds)
{
    int destCode;
    destCode = hashDest(filename);

    
    int breaks, size, extras, parts1, parts2, len;
    getFileData(filename, &breaks, &size);
    char buf[MAXBUF];
    char lineBuf[MAXLINE];

    int connection;

    for(int destServ = 0; destServ < 4; destServ++)
    {
        parts1 = sendMap[destCode][destServ][0] - 1;
        connection = open_connectfd(addrs[destServ], ports[destServ], creds);
        if (parts1 == 3)
        {
            extras = size%4;
        } 
        else
        {
            extras = 0;
        }
        uploadFilePart(filename, connection, breaks, parts1, extras);
    }

    for(int destServ = 0; destServ < 4; destServ++)
    {
        parts2 = sendMap[destCode][destServ][1] - 1;
        connection = open_connectfd(addrs[destServ], ports[destServ], creds);
        if (parts2 == 3)
        {
            extras = size%4;
        } 
        else
        {
            extras = 0;
        }
        uploadFilePart(filename, connection, breaks, parts2, extras);
    }
}

//// Donload

int downloadFilePart(int connid, char* filename, int size, char* buf, int* bufPos)
{
    char filepath[MAXBUF];
    sprintf(filepath, "temp/%s", filename);
    int len = 0;
    int totalLen = (MAXBUF - *bufPos);


    if(size <= (MAXBUF - *bufPos))
    {
        bufferToFile(filepath, buf, size, "w+");
        *bufPos += size; 
    }

    else
    {
        // not sure if works yet...
        char buffer[MAXBUF];
        len = MAXBUF - *bufPos;
        bufferToFile(filepath, buf, len, "w+");

        while(totalLen < size)
        {
            if(MAXBUF <= (size - totalLen))
            {
                len = MAXBUF;
            }
            else 
            {
                len = size - totalLen;
            }

            read(connid, &buffer, len);
            bufferToFile(filepath, &buffer, len, "a");
            totalLen += len;
        }
    }

    fprintf(stderr, "%d bytes saved from server %d\n", size, connid);
    return 0;
}

int downloadFile(char* filename, char addrs[4][MAXLINE], int ports[4], char* creds)
{
    char buf[MAXBUF];
    char extract1[MAXLINE];
    char extract2[MAXLINE];
    int len, linePtr, connection;

    for(int destServ = 0; destServ < 4; destServ++)
    {
        connection = open_connectfd(addrs[destServ], ports[destServ], creds);
        sprintf(buf, "get %s\n", filename);
        send(connection, &buf, strlen(buf), MSG_NOSIGNAL);

        linePtr = 0;
        len = recv(connection, &buf, MAXBUF, 0);
        while(1)
        {
            if(linePtr >= MAXBUF || buf[linePtr] == '\000')
            {
                len = recv(connection, &buf, MAXBUF, 0);
            }

            linePtr += nextWord(&buf, &extract1, linePtr, MAXBUF);
            if(strcmp(extract1, "get") == 0)
            {
                continue;
            }
            else if(strcmp(extract1, "file") != 0)
            {
                break;
            }

            linePtr += nextWord(&buf, &extract1, linePtr, MAXLINE); // file name
            linePtr += nextWord(&buf, &extract2, linePtr, MAXLINE); // file size
            downloadFilePart(connection, extract1, atoi(extract2), &buf[linePtr], &linePtr);
        }
    }
    reconstuctFile(filename);
    fprintf(stderr, "Successfully downloaded %s\n", filename);
}

int main()
{
    int destMap[4][4][2] = {
                            {{1,2},{2,3},{3,4},{4,1}},
                            {{4,1},{1,2},{2,3},{3,4}},
                            {{3,4},{4,1},{1,2},{2,3}},
                            {{2,3},{3,4},{4,1},{1,2}}
                            };

    /// Config Init
    char buf[MAXLINE];
    char user[MAXLINE];
    char pass[MAXLINE];
    char creds[MAXLINE];
    char serverAddrs[4][MAXLINE];
    int serverPorts[4];

    processConfig(&serverAddrs, &serverPorts, &user, &pass);
    sprintf(creds, "%s%s", user, pass);

    int len = 0;
    while(1)
    {            
        /* Promt the user */
        bzero(buf, MAXBUF);
        printf("Please enter msg: ");
        fgets(buf, MAXBUF, stdin);
        len += nextWord(buf, user, 0, MAXLINE);

        if(strcmp(user, "put") == 0)
        {
            len += nextWord(buf, pass, len, MAXLINE);
            FILE* fp;
            fp = fopen(pass, "r");
            if(fp == NULL)
            {
                fprintf(stderr, "%s not in local directory\n", pass);
            }
            else
            {
                /// Download
                uploadFile(pass, serverAddrs, serverPorts, creds);
            }
        }

        if(strcmp(user, "get") == 0)
        {
            len += nextWord(buf, pass, len, MAXLINE);
            /// Upload
            downloadFile(pass, serverAddrs, serverPorts, destMap, creds);
        }

        if(strcmp(user, "list") == 0)
        {
            break;
        }

        if(strcmp(user, "quit") == 0)
        {
            break;
        }

        else
        {
            fprintf(stderr, "Unable to interpret message.\n");
        }
    }

    return 0;
}